﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class GameGlobal : MonoBehaviour
{
    public static string direction="left";
    public static int playerScore=0;
    public static int wave = 0;
    void Start()
    {
        
    }
    void Update()
    {
        
    }



    public static void xd()
    {

    }
}

