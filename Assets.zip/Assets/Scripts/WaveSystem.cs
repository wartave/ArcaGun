﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


[System.Serializable]
public class WaveAction
{
    public string name;
    public float delay;
    public GameObject prefab;
    public int spawnCount;
    public string message;
}
[System.Serializable]
public class Wave
{
    public string name;
    public List<WaveAction> actions;
}



public class WaveSystem : MonoBehaviour
{
    public float difficultyFactor = 0.9f;
    public List<Wave> waves;
    private Wave m_CurrentWave;
    public Wave CurrentWave { get { return m_CurrentWave; } }
    private float m_DelayFactor = 1.0f;
    public List<GameObject> ObjectToSpawn;

    public List<WaveControl> DoorsToSpawn;

    public List<GameObject> EnemiesSpawned;
    IEnumerator SpawnLoop()
    {
        m_DelayFactor = 1.0f;
        while (true)
        {
            foreach (Wave W in waves)
            {
                m_CurrentWave = W;
                foreach (WaveAction A in W.actions)
                {
                    if (A.delay > 0)
                        yield return new WaitForSeconds(A.delay * m_DelayFactor);
                    if (A.message != "")
                    {
                        // TODO: print ingame message
                    }
                    if (A.prefab != null && A.spawnCount > 0)
                    {
                        for (int i = 0; i < A.spawnCount; i++)
                        {
                            if (EnemiesSpawned.Count != A.spawnCount) { 
                                WaveControl ctrlDoor = DoorsToSpawn[(int)Mathf.Round(Random.Range(0, DoorsToSpawn.Count))];
                                StartCoroutine(ctrlDoor.colorShow());
                                Vector3 rndPosWithin = ctrlDoor.FixedPosition;

                                GameObject obj = Instantiate(A.prefab, rndPosWithin, transform.rotation);
                                EnemiesSpawned.Add(obj);
                            }

                        }
                    }
                }
                yield return null;  // prevents crash if all delays are 0
            }
            m_DelayFactor *= difficultyFactor;
            yield return null;  // prevents crash if all delays are 0
        }
    }
    void Start()
    {
        StartCoroutine(SpawnLoop());
    }
}

