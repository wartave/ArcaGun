﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;
using UnityEngine.UI;
public class PlayerController : MonoBehaviour
{

	public float maxSpeed = 5f;
	public float speed = 2f;
	public bool grounded;
	public float jumpPower = 6.5f;

	private Rigidbody2D rb2d;
	private Animator anim;
	private SpriteRenderer spr;
	private bool jump;
	private bool doubleJump;
	private bool movement = true;



	public LayerMask layer;
	private BoxCollider2D cc;
	public Vector2 gunPosition;
	public Vector2 backPosition;


	[Header("Guns")]
	public static bool isHandGun = false;
	public static bool isBackGun = false;

	public static GameObject GunInHand;
	public static GameObject GunInBack;


	[Header("vida")]
	public int vida = 10;
	public Slider vidaSlider;
	void Start()
	{
		rb2d = GetComponent<Rigidbody2D>();
		anim = GetComponent<Animator>();
		spr = GetComponent<SpriteRenderer>();
		cc = GetComponent<BoxCollider2D>();
		vidaSlider.maxValue = 10;
	}

	// Update is called once per frame
	void Update()
	{
		anim.SetFloat("walk", Mathf.Abs(rb2d.velocity.x));
		anim.SetFloat("jump", rb2d.velocity.y);
		anim.SetBool("ground", grounded);

		grounded = IsGrounded();
		if (grounded)
		{
			doubleJump = true;
		}
		
		if (CrossPlatformInputManager.GetButtonDown("Jump"))
		{
			if (grounded)
			{
				jump = true;
				doubleJump = true;
			}
			else if (doubleJump)
			{
				jump = true;
				doubleJump = false;
			}
            
		}
        if (vidaSlider.value != vida)
        {
			vidaSlider.value = vida;

		}
	}

	void FixedUpdate()
	{

		Vector3 fixedVelocity = rb2d.velocity;
		fixedVelocity.x *= 0.75f;

		if (grounded)
		{
			rb2d.velocity = fixedVelocity;
		}

		//float h = Input.GetAxis("Horizontal");
		float h = CrossPlatformInputManager.GetAxisRaw("Horizontal");
		//Debug.Log("boton a: " + h);
		if (!movement) h = 0;;

		rb2d.AddForce(Vector2.right * speed * h);

		float limitedSpeed = Mathf.Clamp(rb2d.velocity.x, -maxSpeed, maxSpeed);
		rb2d.velocity = new Vector2(limitedSpeed, rb2d.velocity.y);

		if (h > 0.1f)
		{
			FlipPlayer(1);
		}if (h < -0.1f)
		{
			FlipPlayer(-1);
		}

		if (jump)
		{
			Jump();
		}


	}


	void Jump()
    {
		rb2d.velocity = new Vector2(rb2d.velocity.x, 0);
		rb2d.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);

			jump = false;
	}

	void OnBecameInvisible()
	{
		transform.position = new Vector3(-1, 0, 0);
	}

	public void EnemyJump()
	{
		jump = true;
	}

	public void EnemyKnockBack(float enemyPosX)
	{
		jump = true;

		float side = Mathf.Sign(enemyPosX - transform.position.x);
		rb2d.AddForce(Vector2.left * side * jumpPower, ForceMode2D.Impulse);

		movement = false;
		Invoke("EnableMovement", 0.7f);

		Color color = new Color(255 / 255f, 106 / 255f, 0 / 255f);
		spr.color = color;
	}

	void EnableMovement()
	{
		movement = true;
		spr.color = Color.white;
	}


	private void FlipPlayer(int dir)
	{
		transform.localScale = new Vector3(dir, transform.localScale.y, transform.localScale.z);

	}
	public bool IsGrounded()
	{
		float extraHeightText = 0.1f;
		RaycastHit2D hit = Physics2D.Raycast(cc.bounds.center, Vector2.down, cc.bounds.extents.y + extraHeightText, layer);
		Color rayColor;
		if (hit.collider != null)
		{
			rayColor = Color.green;
		}
		else
		{
			rayColor = Color.red;
		}
		Debug.DrawRay(cc.bounds.center, Vector2.down * (cc.bounds.extents.y + extraHeightText), rayColor);
		//Debug.Log(hit.collider);
		return hit.collider != null;
	}

}
