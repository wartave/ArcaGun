﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;
using UnityEngine.UI;

public class GunControl : MonoBehaviour
{
    

    
    
    public float dir=1;
    private float playerDir;
    public bool canShoot = true;
   
    public bool isInHand = false;

    [Header("Gun Conf")]
    public int maxAmount = 3;
    public int amount = 0;
    public float waitTime = 1f;
    public float knockbackPower = 0f;
    public float cooldown = 1f;
    public bool rotate = false; 
    public float angleRotation=0;
    public float delay = .2f;


    [Header("Projectile Conf")]
    public GameObject projectile;
    public Vector2 speed = new Vector2(0, 0);
    public float dagameCount = 10f;
    public Vector3 shootPosition;
    [Header("ShootPerticle Conf")]
    public GameObject shootEffect;
    [ColorUsage(true, true, 0f, 8f, 0.125f, 3f)]
    public Color ParticleColor;
    public float originalScale = .2f;
    public float fakeScale = 3f;


    [Header("Item conf")]
    Vector3 pos;
    Rigidbody2D rb2d;
    Rigidbody2D rb2dItem;
    [Header("Cam Conf")]
    public CameraSize camEffect;


   //cuando se dropea
    public bool drop = false;
    public float dropTime = 1f;
    private Material material;

    [Header("Sounds confi")]
    AudioSource audiS;
    public AudioClip AudioCock;//Agarra
    public AudioClip AudioEmpty;//Vacia
    public AudioClip AudioReload;//Cambia
    public AudioClip AudioSilencer;//Shoot
    [Header("UI Config")]
    public Slider slider;


    void Start()
    {
        rb2dItem = GetComponent<Rigidbody2D>();
        audiS = GetComponent<AudioSource>();
        pos = transform.position;
        material = GetComponent<SpriteRenderer>().material;

        material.SetColor("_Color", ParticleColor);
        
    }


    void Update()
    {
        if (isInHand&&drop==false) {
            
            if (CrossPlatformInputManager.GetButtonDown("Change") && PlayerController.isBackGun!=false)
            {
                if (this.gameObject == PlayerController.GunInHand)
                {
                    changeGun();
                }
                
            }
            if (GetComponentInParent<PlayerController>() != null)
            {
                if (dir != GetComponentInParent<PlayerController>().transform.localScale.x)
                {
                    dir = GetComponentInParent<PlayerController>().transform.localScale.x;
                }
            }
            


            if (CrossPlatformInputManager.GetButtonDown("Drop")&&isInHand&&drop==false){
                drop = true;
                
                rb2dItem.bodyType = RigidbodyType2D.Dynamic;
                rb2dItem.AddForce(Vector2.left * -dir * 2, ForceMode2D.Impulse);
                rb2dItem.AddForce(Vector2.up * 10, ForceMode2D.Impulse);


                if (PlayerController.isHandGun)
                {
                    PlayerController.isHandGun = false;
                    PlayerController.GunInHand = null;
                    if (PlayerController.GunInBack!= null)
                    {
                        PlayerController.GunInBack.GetComponent<GunControl>().enabled = true;
                    }
                }

            }





            if (CrossPlatformInputManager.GetButton("Shoot") && canShoot){
                if (amount >= 1){
                    StartCoroutine(camEffect.camShowEffect());
                    
                     
                    Vector3 fizedShootPosition = new Vector3(shootPosition.x * dir, shootPosition.y, shootPosition.z);
                    GameObject obj=Instantiate(shootEffect, transform.position + fizedShootPosition, transform.rotation);


                    obj.GetComponent<ShootParticleConf>().color = ParticleColor;
                    obj.GetComponent<ShootParticleConf>().originalScale = originalScale;
                    obj.GetComponent<ShootParticleConf>().fakeScale = fakeScale;



                    GameObject pro = Instantiate(projectile, transform.position + fizedShootPosition, transform.rotation);
                    pro.GetComponent<Projectile>().show(speed, dir);
                    audiS.clip = AudioSilencer;
                    audiS.Play();
                    amount--;
                    slider.maxValue = maxAmount;
                    slider.value = amount;
                    StartCoroutine(CanShoot());
                    

                    if (knockbackPower > 0)
                    {
                        rb2d.AddForce(Vector2.left * dir * knockbackPower, ForceMode2D.Impulse);
                    }
                    if (rotate==true)
                    {
                        StartCoroutine(Rot());
                        // transform.Rotate(0, 0, 90);
                        //yield return new WaitForSeconds(.6f);
                        // transform.Rotate(0, 0, 0);
                    }
                }
                if (amount <= 0)
                { //Si no tiene balas 
                    audiS.clip = AudioEmpty;
                    audiS.Play();

                }

            }

            
        }else if(rb2dItem.bodyType==RigidbodyType2D.Kinematic&&transform.parent==null){
                float newY = Mathf.Sin(Time.time * 2) * .2f + pos.y;
                transform.position = new Vector3(transform.position.x, newY, transform.position.z);
        }
        if (drop)
        {
            if (dropTime != 0){

                dropTime -= Time.deltaTime*0.8f;
            }
            if(dropTime<=0){ Destroy(this.gameObject); }

            transform.Rotate(new Vector3(0, 0, 1), Space.World);
            material.SetFloat("_Fade", dropTime);

        }

        if (PlayerController.GunInHand == null)
        {
            if (PlayerController.isHandGun == false && transform.parent != null)
            {
                Debug.Log("hand false");
              //  Debug.Log("hand back id:" + PlayerController.GunInBack.name);
               // Debug.Log("hand gameobject id:" + this.gameObject.name);
                if (PlayerController.GunInBack == this.gameObject)
                {
                    PlayerController.GunInBack.GetComponent<SpriteRenderer>().sortingLayerName = "guns";
                    PlayerController.GunInBack.GetComponent<SpriteRenderer>().sortingOrder = 0;


                    Transform childp = transform.parent.GetChild(1);
                    PlayerController.GunInBack.transform.position = new Vector3(childp.transform.position.x, childp.transform.position.y, childp.transform.position.z);
                    PlayerController.GunInBack.transform.rotation = childp.rotation;

                    PlayerController.GunInHand = this.gameObject;
                    PlayerController.isHandGun = true;
                    PlayerController.GunInBack = null;
                    PlayerController.isBackGun = false;
                    PlayerController.GunInHand.GetComponent<GunControl>().isInHand = true;
                    PlayerController.GunInHand.GetComponent<GunControl>().drop = false;


                }


            }
        }
    }


    /*IEnumerator FadeEffecr()
    {

        yield return new WaitForSeconds()
    }*/

     void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player"&& isInHand==false){
            GameObject player = collision.gameObject;
            if(PlayerController.isHandGun == false)
            {
                rb2d = player.GetComponent<Rigidbody2D>();
                Transform childp = collision.gameObject.transform.GetChild(1);
                Debug.Log(childp.tag);
                dir = collision.gameObject.transform.localScale.x;

                this.transform.localScale = new Vector3(dir, this.transform.localScale.y, this.transform.localScale.z);
                this.transform.parent = collision.gameObject.transform;
                this.transform.position = new Vector3(childp.transform.position.x, childp.transform.position.y, this.transform.position.z);
                isInHand = true;
                PlayerController.isHandGun = true;
                PlayerController.GunInHand = this.gameObject;
                audiS.clip = AudioCock;
                audiS.Play();
                slider.maxValue = maxAmount;
                slider.value = amount;
            }
            else if (PlayerController.isBackGun == false)
            {
                PlayerController.GunInHand.GetComponent<GunControl>().isInHand = false;
                PlayerController.GunInHand.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
                PlayerController.GunInHand.GetComponent<SpriteRenderer>().sortingOrder =- 1;
               


                Transform childd = collision.gameObject.transform.GetChild(2);
                PlayerController.GunInHand.transform.position= new Vector3(childd.transform.position.x, childd.transform.position.y, this.transform.position.z);

                PlayerController.GunInHand.transform.rotation = childd.rotation;
               PlayerController.GunInBack = PlayerController.GunInHand;

                PlayerController.GunInBack.GetComponent<GunControl>().enabled = false;

                rb2d = player.GetComponent<Rigidbody2D>();
                Transform childp = collision.gameObject.transform.GetChild(1);
                Debug.Log(childp.tag);
                dir = collision.gameObject.transform.localScale.x;


                this.transform.localScale = new Vector3(dir, this.transform.localScale.y, this.transform.localScale.z);
                this.transform.parent = collision.gameObject.transform;
                this.transform.position = new Vector3(childp.transform.position.x, childp.transform.position.y, this.transform.position.z);
                isInHand = true;
                PlayerController.isHandGun = true;
                PlayerController.GunInHand = this.gameObject;
                PlayerController.isBackGun = true;
                audiS.clip = AudioCock;
                audiS.Play();
            }
        }
    }


    IEnumerator CanShoot()
    {
        canShoot = false;
        yield return new WaitForSeconds(cooldown);
        canShoot = true;


    }
    IEnumerator Rot()
    {
        float angle=(dir==1)?angleRotation: -angleRotation;
        transform.Rotate(new Vector3(0, 0, angle), Space.World);
        yield return new WaitForSeconds(delay);
        transform.Rotate(new Vector3(0, 0,360 - angle), Space.World);
    }


    public void changeGun()
    {
        if (PlayerController.isBackGun)
        {
            PlayerController.GunInBack.GetComponent<SpriteRenderer>().sortingLayerName = "guns";
            PlayerController.GunInBack.GetComponent<SpriteRenderer>().sortingOrder = 0;


            Transform childp = transform.parent.GetChild(1) ;
            PlayerController.GunInBack.transform.position = new Vector3(childp.transform.position.x, childp.transform.position.y, childp.transform.position.z);


            PlayerController.GunInBack.transform.rotation = childp.rotation;

            PlayerController.GunInHand.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
            PlayerController.GunInHand.GetComponent<SpriteRenderer>().sortingOrder = -1;



            Transform childd = transform.parent.GetChild(2);
            PlayerController.GunInHand.transform.position = new Vector3(childd.transform.position.x, childd.transform.position.y, childd.transform.position.z);
            PlayerController.GunInHand.transform.rotation = childd.rotation;


            PlayerController.GunInBack.GetComponent<GunControl>().enabled = true;
            PlayerController.GunInHand.GetComponent<GunControl>().enabled = false;

            GameObject newObjA = PlayerController.GunInBack;
            GameObject newObjB = PlayerController.GunInHand;

            PlayerController.GunInBack.GetComponent<GunControl>().isInHand = true;
            PlayerController.GunInHand.GetComponent<GunControl>().isInHand = false;

            PlayerController.GunInBack = null;
            PlayerController.GunInHand = null;


            PlayerController.GunInBack = newObjB;
            PlayerController.GunInHand = newObjA;
            audiS.clip = AudioReload;
            audiS.Play();

            //AudioReload;

            slider.maxValue = maxAmount;
            slider.value = amount;





        }


        //Debug.Log("A: " + PlayerController.GunInHand.name);
        //Debug.Log("B: " + PlayerController.GunInBack.name);


    }



#if UNITY_EDITOR
    void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Vector3 fizedShootPosition = new Vector3(shootPosition.x * dir, shootPosition.y, shootPosition.z);
        Gizmos.DrawRay(transform.position, fizedShootPosition);
    }
#endif
}
