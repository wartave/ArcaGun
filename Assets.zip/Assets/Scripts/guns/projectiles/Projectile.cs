﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float direcion = 1;
    public int damage = 1;
    Rigidbody2D rg2d;

    public LayerMask ground;
    public LayerMask enemies;
    void Start()
    {
        rg2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update(){
        
    }
    public void show(Vector2 speed, float dire)
    {
        rg2d = GetComponent<Rigidbody2D>();
        rg2d.velocity = new Vector2(speed.x * dire, speed.y);
        //Debug.Log(dire);
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("trigeter: "+ collision.gameObject.layer);
        Debug.Log("value: " + ground.value);
        //if (collision)
        if(collision.gameObject.tag == "ground")
        {
            Destroy(this.gameObject);
        }
       // LayerMask.
        if (collision.gameObject.tag == "enemy")
        {
            if (collision.gameObject.GetComponent<Zombie>() != null)
            {
                collision.gameObject.GetComponent<Zombie>().Damage(damage);
                Destroy(this.gameObject);
            }
        }

    }
}
