﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zombie : MonoBehaviour
{

	float dirX;

	[SerializeField]
	float moveSpeed = 3f;

	Rigidbody2D rb;

	bool facingRight = false;

	Vector3 localScale;

	public bool isAttacking = false;

	Animator anim;


	public int health = 10;
	Material material;
	public Color originalColor;
	[ColorUsage(true, true, 0f, 8f, 0.125f, 3f)]
	public Color DamageColor;

	// Use this for initialization
	void Start()
	{
		localScale = transform.localScale;
		rb = GetComponent<Rigidbody2D>();
		dirX = -1f;

		anim = GetComponent<Animator>();
		material = GetComponent<SpriteRenderer>().material;
		//originalColor=material.color;
	}

	// Update is called once per frame
	void Update()
	{
		if (transform.position.x < -9f)
			dirX = 1f;
		else if (transform.position.x > 9f)
			dirX = -1f;

		//if (isAttacking)
			//anim.SetBool("isAttacking", true);
		//else
			//anim.SetBool("isAttacking", false);

	}

	void FixedUpdate()
	{
		if (!isAttacking)
			rb.velocity = new Vector2(dirX * moveSpeed, rb.velocity.y);
		else
			rb.velocity = Vector2.zero;
	}

	void LateUpdate()
	{
		CheckWhereToFace();
	}


	public void Damage(int damage)
    {
        if (health != 0)
        {
			StartCoroutine(ColorChange(damage));
        }
        else if(health<=0)
        {
			Destroy(this.gameObject);
        }
		
    }


	IEnumerator ColorChange(int damage)
    {
		health -= damage;
		material.SetColor("_Tint", DamageColor);
		yield return new WaitForSeconds(.1f);
		material.SetColor("_Tint", originalColor);
		yield return new WaitForSeconds(.1f);
		material.SetColor("_Tint", DamageColor);
		yield return new WaitForSeconds(.1f);
		material.SetColor("_Tint", originalColor);
	}

	void CheckWhereToFace(){
		if (dirX > 0)
			facingRight = true;
		else if (dirX < 0)
			facingRight = false;

		if (((facingRight) && (localScale.x < 0)) || ((!facingRight) && (localScale.x > 0)))
			localScale.x *= -1;

		transform.localScale = localScale;
	}
}
