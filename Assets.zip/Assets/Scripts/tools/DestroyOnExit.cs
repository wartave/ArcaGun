﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOnExit : MonoBehaviour {
	Camera cam;
	void Start () {
		cam = Camera.main;
	}
	void Update () {
		Vector3 viewPos = cam.WorldToViewportPoint (transform.position);
		if (viewPos.x >= 0 && viewPos.x <= 1 && viewPos.y >= 0 && viewPos.y <= 1 && viewPos.z > 0) {
			
		} else {
			Destroy (this.gameObject);
		}
	}
}
