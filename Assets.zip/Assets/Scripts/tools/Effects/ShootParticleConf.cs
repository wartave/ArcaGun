﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShootParticleConf : MonoBehaviour
{
    public float originalScale = 1f;
    public float fakeScale = 1.1f;
    [ColorUsageAttribute(true, true, 0f, 8f, 0.125f, 3f)]
    public Color color;

    public float time;


    private SpriteRenderer spr;

    void Start()
    {
        transform.localScale = new Vector3(originalScale, originalScale, 1);
        spr = GetComponent<SpriteRenderer>();

        spr.material.SetColor("_Color", color);
        StartCoroutine(effect());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator effect()
    {
        transform.localScale = new Vector3(fakeScale, fakeScale, 1);
        yield return new WaitForSeconds(time);
        transform.localScale = new Vector3(originalScale, originalScale, 1);
        yield return new WaitForSeconds(time);
        transform.localScale = new Vector3(fakeScale, fakeScale, 1);
    }
}
