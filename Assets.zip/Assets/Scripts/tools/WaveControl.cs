﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveControl : MonoBehaviour
{

    
    [ColorUsage(true, true, 0f, 8f, 0.125f, 3f)]
    public Color colorWave;
    Material material;


    [Header("spawn Conf")]
    public Vector3 spawnPosition;
    public Vector3 FixedPosition;
    void Start()
    {
        FixedPosition = spawnPosition + transform.position;
        material = GetComponent<SpriteRenderer>().material;
        material.SetColor("_Color", colorWave);
    }

    void Update()
    {

    }
    public IEnumerator colorShow()
    {
        material.SetFloat("_Fade", 1f);
        yield return new WaitForSeconds(.1f);
        material.SetFloat("_Fade", 255f);
        yield return new WaitForSeconds(.1f);
        material.SetFloat("_Fade", 1f);
        yield return new WaitForSeconds(.1f);
        material.SetFloat("_Fade", 255f);
    }


#if UNITY_EDITOR
    void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Vector3 fizedShootPosition = new Vector3(spawnPosition.x , spawnPosition.y, spawnPosition.z);
        Gizmos.DrawRay(transform.position, fizedShootPosition);
    }
#endif
}
