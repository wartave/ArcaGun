﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraSize : MonoBehaviour
{
    public SpriteRenderer rink;


    public float originalSize = 0;
    public float fakeSize = 1f;
    public float camEffect = 0;
    public float time = .2f;
    void Start()
    {
        Camera.main.orthographicSize = rink.bounds.size.x * Screen.height / Screen.width * 0.5f;
        originalSize = rink.bounds.size.x * Screen.height / Screen.width * 0.5f;
        camEffect = originalSize + fakeSize;
    }
    void Update()
    {
        
    }

    public IEnumerator camShowEffect()
    {
        Camera.main.orthographicSize = camEffect;
        yield return new WaitForSeconds(time);
        Camera.main.orthographicSize = originalSize;

    }
}
