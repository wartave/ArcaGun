﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraEffect : MonoBehaviour
{
    Camera cam;
    public float originalSize = 0;
    public float fakeSize = 1f;
    public float camEffect = 0;
    public float time=.2f;
    void Start()
    {
        cam = Camera.main;
        originalSize = Camera.main.orthographicSize;
        camEffect = originalSize + originalSize;

    }

    void Update()
    {
        
    }

    public IEnumerator camShowEffect()
    {
        Camera.main.orthographicSize = camEffect;
        yield return new WaitForSeconds(time);
        Camera.main.orthographicSize = originalSize;
        yield return new WaitForSeconds(time);
        Camera.main.orthographicSize = camEffect;
        yield return new WaitForSeconds(time);
        Camera.main.orthographicSize = originalSize;

    }
}
