﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class followPlayer : MonoBehaviour
{
	public Transform target;
	public float smoothSpeed = 0.125f;
	public Vector3 offset;

	public bool bounds;
	public Vector3 minPosition;
	public Vector3 maxPosition;
	// Update is called once per frame
	Camera cam;
	Vector3 positionScroll;
	
	void Start()
	{
		cam = Camera.main;
	}

	void FixedUpdate()
	{
		if (target != null)
		{
			Vector3 desiredPosition = target.position + offset;
			Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
			transform.position = new Vector3(smoothedPosition.x, smoothedPosition.y + offset.y, -10f + offset.z);
			transform.position = new Vector3(Mathf.Clamp(transform.position.x, minPosition.x, maxPosition.x),
				Mathf.Clamp(transform.position.y, minPosition.y, maxPosition.y),
				Mathf.Clamp(transform.position.z, minPosition.z, maxPosition.z)
			);
		}
	}
}
